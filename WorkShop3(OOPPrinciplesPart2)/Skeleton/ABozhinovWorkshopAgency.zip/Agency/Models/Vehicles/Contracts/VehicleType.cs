﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Agency.Models.Vehicles.Contracts
{
    public enum VehicleType
    {
        Land,
        Air,
        Sea
    }
}
