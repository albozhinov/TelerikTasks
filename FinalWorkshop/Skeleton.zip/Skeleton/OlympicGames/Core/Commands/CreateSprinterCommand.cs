﻿using System.Collections.Generic;

using OlympicGames.Core.Contracts;
using OlympicGames.Olympics.Contracts;

namespace OlympicGames.Core.Commands
{
    public class CreateSprinterCommand
    {
        // Consider using the dictionary
        private readonly IDictionary<string, double> records;
    }
}
