﻿using Cosmetics.Core.Engine;

namespace Cosmetics
{

    public class Startup
    {
        public static void Main()
        {
            CosmeticsEngine.Instance.Start();
        }
    }
}
